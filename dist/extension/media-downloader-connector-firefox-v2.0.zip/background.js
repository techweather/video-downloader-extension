// Create context menu items
browser.contextMenus.create({
  id: "download-video",
  title: "Download Video",
  contexts: ["page", "link", "video"]
});

browser.contextMenus.create({
  id: "download-image", 
  title: "Download Image",
  contexts: ["image"]
});

browser.contextMenus.create({
  id: "pick-images",
  title: "Pick Images (ESC to stop)",
  contexts: ["page"]
});

browser.contextMenus.create({
  id: "scrape-videos", 
  title: "📄 Download All Videos (Scroll Page First!)",
  contexts: ["page"]
});

// Handle context menu clicks
browser.contextMenus.onClicked.addListener((info, tab) => {
  console.log('Menu clicked:', info.menuItemId);
  
  if (info.menuItemId === "download-video") {
    // Get the URL - could be the page, a link, or video element
    const url = info.linkUrl || info.srcUrl || info.pageUrl;
    
    // Extract page metadata including thumbnail
    browser.tabs.executeScript(tab.id, {
      code: `
        (() => {
          let thumbnail = null;
          
          // Try various meta tags for thumbnail
          const metaTags = [
            'meta[property="og:image"]',
            'meta[name="twitter:image"]',
            'meta[itemprop="thumbnailUrl"]',
            'link[rel="image_src"]'
          ];
          
          for (const selector of metaTags) {
            const meta = document.querySelector(selector);
            if (meta) {
              thumbnail = meta.content || meta.href;
              break;
            }
          }
          
          // YouTube specific
          if (window.location.hostname.includes('youtube.com')) {
            const videoId = new URLSearchParams(window.location.search).get('v');
            if (videoId) {
              thumbnail = 'https://img.youtube.com/vi/' + videoId + '/maxresdefault.jpg';
            }
          }
          
          // Instagram specific - try to find image in post
          if (window.location.hostname.includes('instagram.com')) {
            const img = document.querySelector('article img');
            if (img) thumbnail = img.src;
          }
          
          return {
            title: document.title,
            thumbnail: thumbnail,
            source: window.location.hostname
          };
        })();
      `
    }, function(results) {
      const pageData = results[0] || {};
      
      // Send to native app via HTTP
      sendToNativeApp({
        type: 'video',
        url: url,
        title: pageData.title || tab.title,
        thumbnail: pageData.thumbnail,
        source: pageData.source || new URL(url).hostname
      });
    });
  }
  
  else if (info.menuItemId === "download-image") {
    sendToNativeApp({
      type: 'image',
      url: info.srcUrl,
      thumbnail: info.srcUrl,  // For images, use the image itself as thumbnail
      pageUrl: info.pageUrl,
      source: new URL(info.pageUrl).hostname
    });
  }
  
  else if (info.menuItemId === "pick-images") {
    // Inject the image picker script
    browser.tabs.executeScript(tab.id, { file: "image-picker.js" });
  }
  
  else if (info.menuItemId === "scrape-videos") {
    console.log('Starting video scrape...');
    
    // Show informative alert about scrolling first
    browser.tabs.executeScript(tab.id, {
      code: `
        if (confirm("📄 IMPORTANT: Video Detection Tips\\n\\n" +
                   "✅ For best results, SCROLL through the entire page first!\\n" +
                   "✅ This loads lazy-loaded videos and dynamic content\\n" +
                   "✅ Wait for videos to appear before running this scan\\n\\n" +
                   "Many modern websites only load videos when they come into view.\\n\\n" +
                   "Click OK to proceed with video detection, or Cancel to scroll first.")) {
          // User confirmed, proceed with scanning
          true;
        } else {
          // User cancelled, stop here
          false;
        }
      `
    }, function(results) {
      if (browser.runtime.lastError) {
        console.error('Script injection error:', browser.runtime.lastError);
        return;
      }
      
      const userConfirmed = results && results[0];
      if (!userConfirmed) {
        console.log('User cancelled video scraping to scroll first');
        return;
      }
      
      console.log('User confirmed, proceeding with video scraping...');
      
      // First, inject a content script that will do the scraping
      browser.tabs.executeScript(tab.id, {
      code: `
        console.log('Video scraper starting...');
        
        // Send result back to background script
        function sendVideosToBackground(videos, pageTitle, pageUrl) {
          browser.runtime.sendMessage({
            action: 'videos-found',
            videos: videos,
            pageTitle: pageTitle,
            pageUrl: pageUrl
          });
        }
        
        try {
          const videos = [];
          const processedUrls = new Set();
          
          // Helper to resolve relative URLs
          function resolveUrl(url) {
            if (!url) return null;
            try {
              return new URL(url, window.location.href).href;
            } catch {
              return null;
            }
          }
          
          // Helper to find nearby text for better naming
          function findNearbyText(element) {
            // Look for parent containers
            let parent = element;
            let attempts = 0;
            while (parent && attempts < 5) {
              parent = parent.parentElement;
              attempts++;
              
              // Look for headings
              const headings = parent ? parent.querySelectorAll('h1, h2, h3, h4, h5') : [];
              for (const heading of headings) {
                const text = heading.textContent.trim();
                if (text && text.length > 3 && text.length < 100) {
                  return text;
                }
              }
              
              // Look for aria-labels or titles
              if (parent) {
                const ariaLabel = parent.getAttribute('aria-label');
                if (ariaLabel && ariaLabel.length > 3) return ariaLabel;
                
                const title = parent.getAttribute('title');
                if (title && title.length > 3) return title;
              }
            }
            
            return null;
          }
          
          // Helper to find nearby image as thumbnail
          function findNearbyImage(element) {
            // First check the video element itself for poster
            if (element && element.poster) {
              return resolveUrl(element.poster);
            }
            
            // Look for images in parent containers
            let parent = element;
            let attempts = 0;
            while (parent && attempts < 4) {
              parent = parent.parentElement;
              attempts++;
              
              if (parent) {
                // Look for img tags
                const imgs = parent.querySelectorAll('img');
                for (const img of imgs) {
                  if (img.src && !img.src.includes('data:') && img.width > 50) {
                    return resolveUrl(img.src);
                  }
                }
                
                // Look for background images
                const bgImage = window.getComputedStyle(parent).backgroundImage;
                if (bgImage && bgImage !== 'none') {
                  const match = bgImage.match(/url\\(["']?(.+?)["']?\\)/);
                  if (match && !match[1].includes('data:')) {
                    return resolveUrl(match[1]);
                  }
                }
              }
            }
            
            // Last resort: find any decent sized image on the page
            const allImages = document.querySelectorAll('img');
            for (const img of allImages) {
              if (img.src && !img.src.includes('data:') && img.width > 200 && img.height > 100) {
                return resolveUrl(img.src);
              }
            }
            
            return null;
          }
          
          // Helper to extract filename from URL
          function getFilenameFromUrl(url) {
            try {
              const pathname = new URL(url).pathname;
              const filename = pathname.split('/').pop();
              if (filename && filename.includes('.')) {
                return filename.split('.')[0]; // Return without extension
              }
            } catch {}
            return null;
          }
          
          // 1. Find all <video> elements
          console.log('Looking for video elements...');
          const videoElements = document.querySelectorAll('video');
          console.log('Found', videoElements.length, 'video elements');
          
          videoElements.forEach((video, index) => {
            // Check for direct source
            if (video.src) {
              const url = resolveUrl(video.src);
              console.log('Video src:', url);
              if (url && !processedUrls.has(url)) {
                processedUrls.add(url);
                
                // Try to find a good title
                let title = findNearbyText(video);
                if (!title) {
                  const filename = getFilenameFromUrl(url);
                  title = filename || ('Video ' + (videos.length + 1));
                }
                
                // Try to find thumbnail
                const thumbnail = findNearbyImage(video);
                
                videos.push({
                  url: url,
                  type: 'direct',
                  title: title,
                  thumbnail: thumbnail,
                  originalFilename: getFilenameFromUrl(url)
                });
              }
            }
            
            // Check for <source> elements
            video.querySelectorAll('source').forEach(source => {
              const url = resolveUrl(source.src);
              console.log('Source src:', url);
              if (url && !processedUrls.has(url)) {
                processedUrls.add(url);
                
                let title = findNearbyText(video);
                if (!title) {
                  const filename = getFilenameFromUrl(url);
                  title = filename || ('Video ' + (videos.length + 1));
                }
                
                const thumbnail = findNearbyImage(video);
                
                videos.push({
                  url: url,
                  type: source.type || 'direct',
                  title: title,
                  thumbnail: thumbnail,
                  originalFilename: getFilenameFromUrl(url)
                });
              }
            });
          });
          
          // 2. Look for Apple's lazy-loaded videos
          console.log('Looking for Apple video patterns...');
          // Apple uses data attributes
          const elementsWithVideoData = document.querySelectorAll('[data-video-src], [data-mp4-src], video[data-src]');
          console.log('Found', elementsWithVideoData.length, 'elements with video data attributes');
          
          elementsWithVideoData.forEach(element => {
            ['data-video-src', 'data-mp4-src', 'data-src'].forEach(attr => {
              const url = element.getAttribute(attr);
              if (url) {
                const fullUrl = resolveUrl(url);
                console.log('Data attribute URL:', fullUrl);
                if (fullUrl && !processedUrls.has(fullUrl)) {
                  processedUrls.add(fullUrl);
                  
                  let title = findNearbyText(element);
                  if (!title) {
                    const filename = getFilenameFromUrl(fullUrl);
                    title = filename || ('Video ' + (videos.length + 1));
                  }
                  
                  const thumbnail = findNearbyImage(element);
                  
                  videos.push({
                    url: fullUrl,
                    type: 'data-attribute',
                    title: title,
                    thumbnail: thumbnail,
                    originalFilename: getFilenameFromUrl(fullUrl)
                  });
                }
              }
            });
          });
          
          // 3. Look in srcset attributes (Apple uses these)
          document.querySelectorAll('[srcset*=".mp4"]').forEach(element => {
            const srcset = element.getAttribute('srcset');
            if (srcset) {
              // Extract MP4 URLs from srcset
              const matches = srcset.match(/[^\\s,]+\\.mp4/g);
              if (matches) {
                matches.forEach(match => {
                  const url = resolveUrl(match);
                  if (url && !processedUrls.has(url)) {
                    console.log('Found in srcset:', url);
                    processedUrls.add(url);
                    
                    let title = findNearbyText(element);
                    if (!title) {
                      const filename = getFilenameFromUrl(url);
                      title = filename || ('Video ' + (videos.length + 1));
                    }
                    
                    const thumbnail = findNearbyImage(element);
                    
                    videos.push({
                      url: url,
                      type: 'srcset',
                      title: title,
                      thumbnail: thumbnail,
                      originalFilename: getFilenameFromUrl(url)
                    });
                  }
                });
              }
            }
          });
          
          console.log('Total videos found:', videos.length);
          console.log('Videos with details:', videos);
          
          if (videos.length === 0) {
            alert('No videos found on this page. The page may use a different video delivery method or videos may not be loaded yet.');
          } else {
            // Send the videos back to background script
            sendVideosToBackground(videos, document.title, window.location.href);
          }
          
        } catch (error) {
          console.error('Error scanning for videos:', error);
          alert('Error scanning for videos: ' + error.message);
        }
      `
      }, function() {
        if (browser.runtime.lastError) {
          console.error('Script injection error:', browser.runtime.lastError);
        }
      });
    });
  }
});

// Listen for messages from content scripts
browser.runtime.onMessage.addListener((message, sender) => {
  console.log('Received message:', message.action);
  
  if (message.action === "download-image") {
    sendToNativeApp({
      type: 'image',
      url: message.url,
      thumbnail: message.thumbnail || message.url,
      pageUrl: sender.tab.url,
      source: new URL(sender.tab.url).hostname
    });
  }
  else if (message.action === "videos-found") {
    console.log('Videos found, sending to native app:', message.videos.length);
    
    // Send to native app
    sendToNativeApp({
      type: 'video-list',
      videos: message.videos,
      pageTitle: message.pageTitle,
      pageUrl: message.pageUrl,
      source: new URL(message.pageUrl).hostname
    });
  }
});

// Send data to native app
function sendToNativeApp(data) {
  console.log('Sending to native app:', data);
  
  // Simple HTTP POST to local native app
  fetch('http://127.0.0.1:5555/download', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(data)
  })
  .then(response => response.json())
  .then(result => {
    console.log('Sent to native app:', result);
  })
  .catch(error => {
    console.error('Failed to connect to native app:', error);
    alert('Failed to connect to downloader app. Make sure it is running.');
  });
}